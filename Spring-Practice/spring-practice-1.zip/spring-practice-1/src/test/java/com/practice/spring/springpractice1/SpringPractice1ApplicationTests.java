package com.practice.spring.springpractice1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPractice1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
